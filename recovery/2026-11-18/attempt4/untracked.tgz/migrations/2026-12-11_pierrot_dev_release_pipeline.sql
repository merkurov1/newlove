-- Pierrot Dev — commit-first release pipeline ("Ready to Push")
-- Date: 2026-12-11
--
-- ADDITIVE ONLY. Do NOT apply automatically to production.
--
-- This migration extends the existing Workbench. It does not create a second
-- execution queue: tasks and attempts stay in pierrot_dev_prompts /
-- pierrot_dev_attempts. It adds:
--   * pierrot_dev_releases       — one explicit owner promotion attempt
--   * pierrot_dev_release_items  — per task/commit progress inside a release
--
-- Design notes:
--   * A release row is created by the single owner action "Push ready commits".
--   * Idempotency is enforced by a unique idempotency_key plus a partial unique
--     index that keeps one task/commit in at most one active release.
--   * Every GitHub/Vercel confirmation is stored on the item, so a worker or
--     Vercel restart can resume from durable state instead of guessing.
--   * No tokens, headers or credentials are stored here.
--   * The task status constraint is widened with the commit-first states. Old
--     rows keep their existing values.
--
-- Manual application and verification are documented at the end of the file.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- Release batches
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.pierrot_dev_releases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  repository TEXT NOT NULL DEFAULT 'newlove',
  base_ref TEXT NOT NULL DEFAULT 'main',
  status TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN (
      'draft', 'blocked', 'pushing', 'partial', 'in_main',
      'deployment_pending', 'deployed', 'failed'
    )),
  idempotency_key TEXT UNIQUE
    CHECK (idempotency_key IS NULL OR length(btrim(idempotency_key)) BETWEEN 8 AND 200),
  selected_task_ids UUID[] NOT NULL DEFAULT '{}',
  item_count INTEGER NOT NULL DEFAULT 0 CHECK (item_count >= 0),
  main_before_sha TEXT,
  main_after_sha TEXT,
  deployment_id TEXT,
  deployment_url TEXT,
  deployment_state TEXT,
  deployment_checked_at TIMESTAMPTZ,
  block_reason TEXT,
  error_code TEXT,
  error_message TEXT,
  preflight JSONB NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(preflight) = 'object' AND pg_column_size(preflight) <= 65536),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS pierrot_dev_releases_status_idx
  ON public.pierrot_dev_releases (status, created_at DESC);
CREATE INDEX IF NOT EXISTS pierrot_dev_releases_user_idx
  ON public.pierrot_dev_releases (user_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Per-task progress inside a release
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.pierrot_dev_release_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  release_id UUID NOT NULL
    REFERENCES public.pierrot_dev_releases(id) ON DELETE CASCADE,
  task_id UUID NOT NULL
    REFERENCES public.pierrot_dev_prompts(id) ON DELETE CASCADE,
  task_title TEXT NOT NULL DEFAULT '',
  repository TEXT NOT NULL DEFAULT 'newlove',
  base_ref TEXT NOT NULL DEFAULT 'main',
  attempt_id UUID
    REFERENCES public.pierrot_dev_attempts(id) ON DELETE SET NULL,
  position INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'ready'
    CHECK (status IN (
      'committed', 'ready', 'blocked', 'conflict', 'already_in_main',
      'pushing', 'in_main', 'deployment_pending', 'deployed',
      'deployment_failed', 'failed', 'skipped'
    )),
  commit_sha TEXT NOT NULL CHECK (commit_sha ~ '^[0-9a-f]{7,40}$'),
  branch TEXT NOT NULL,
  pr_number INTEGER,
  pr_url TEXT,
  changed_files TEXT[] NOT NULL DEFAULT '{}',
  checks JSONB NOT NULL DEFAULT '[]'::jsonb
    CHECK (jsonb_typeof(checks) = 'array' AND pg_column_size(checks) <= 65536),
  validation JSONB NOT NULL DEFAULT '{}'::jsonb
    CHECK (jsonb_typeof(validation) = 'object' AND pg_column_size(validation) <= 65536),
  block_reason TEXT,
  committed_at TIMESTAMPTZ,
  pushed_at TIMESTAMPTZ,
  main_sha TEXT,
  deployed_sha TEXT,
  deployment_id TEXT,
  deployment_url TEXT,
  deployment_state TEXT,
  deployment_checked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (release_id, task_id)
);

CREATE INDEX IF NOT EXISTS pierrot_dev_release_items_release_idx
  ON public.pierrot_dev_release_items (release_id, position);
CREATE INDEX IF NOT EXISTS pierrot_dev_release_items_task_idx
  ON public.pierrot_dev_release_items (task_id, created_at DESC);
CREATE INDEX IF NOT EXISTS pierrot_dev_release_items_state_idx
  ON public.pierrot_dev_release_items (status, updated_at DESC);

-- A commit can be in only one active release. `deployed` is terminal, so a
-- later reconciliation or a re-selection cannot create a duplicate merge.
CREATE UNIQUE INDEX IF NOT EXISTS pierrot_dev_release_items_active_task_idx
  ON public.pierrot_dev_release_items (task_id)
  WHERE status IN ('pushing', 'in_main', 'deployment_pending');

-- A task/commit can only be in one live release at a time. Terminal failure
-- states (failed/conflict/blocked) are deliberately excluded so the owner can
-- retry the same commit safely; a new attempt has a new SHA.
CREATE UNIQUE INDEX IF NOT EXISTS pierrot_dev_release_items_task_commit_idx
  ON public.pierrot_dev_release_items (task_id, commit_sha)
  WHERE status IN ('ready', 'pushing', 'in_main', 'deployment_pending', 'deployed');

-- ---------------------------------------------------------------------------
-- Task status vocabulary: commit-first states
-- ---------------------------------------------------------------------------

DO $$
BEGIN
  ALTER TABLE public.pierrot_dev_prompts
    DROP CONSTRAINT IF EXISTS pierrot_dev_prompts_status_check;

  ALTER TABLE public.pierrot_dev_prompts
    ADD CONSTRAINT pierrot_dev_prompts_status_check
    CHECK (status IN (
      'draft',
      'ready',
      'queued',
      'in_progress',
      'review',
      'verified',
      'failed',
      'rejected',
      'cancelled',
      'archived',
      'blocked',
      'used',
      'committed',
      'validation_failed',
      'ready_to_push',
      'pushing',
      'in_main',
      'deployment_pending',
      'deployed',
      'deployment_failed',
      'no_changes'
    ));
END $$;

-- ---------------------------------------------------------------------------
-- Security: server-only, exactly like the rest of the Workbench
-- ---------------------------------------------------------------------------

ALTER TABLE public.pierrot_dev_releases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pierrot_dev_release_items ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.pierrot_dev_releases FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.pierrot_dev_release_items FROM PUBLIC, anon, authenticated;

GRANT ALL ON TABLE public.pierrot_dev_releases TO service_role;
GRANT ALL ON TABLE public.pierrot_dev_release_items TO service_role;

COMMENT ON TABLE public.pierrot_dev_releases IS
  'Owner-triggered "Push ready commits" batches. One row per explicit promotion request.';
COMMENT ON TABLE public.pierrot_dev_release_items IS
  'Durable per-task promotion and deployment progress. No secrets are stored.';
COMMENT ON COLUMN public.pierrot_dev_release_items.main_sha IS
  'The squash-merge commit confirmed present in main by GitHub.';
COMMENT ON COLUMN public.pierrot_dev_release_items.deployed_sha IS
  'The main revision whose Vercel production deployment reached READY.';

-- Manual verification (not executed automatically):
--   SELECT table_name FROM information_schema.tables
--    WHERE table_schema = 'public'
--      AND table_name IN ('pierrot_dev_releases', 'pierrot_dev_release_items');
--   SELECT relname, relrowsecurity FROM pg_class
--    WHERE relname IN ('pierrot_dev_releases', 'pierrot_dev_release_items');
--   SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint
--    WHERE conrelid = 'public.pierrot_dev_prompts'::regclass
--      AND conname = 'pierrot_dev_prompts_status_check';
--   SELECT indexname FROM pg_indexes
--    WHERE tablename = 'pierrot_dev_release_items';
