/** @jest-environment node */

jest.mock('../store', () => {
  const tasks = new Map<string, Record<string, unknown>>();
  const attempts = new Map<string, Record<string, unknown>>();
  let release: Record<string, unknown> | null = null;
  let items: Array<Record<string, unknown>> = [];
  let nextItem = 1;

  const store = {
    __tasks: tasks,
    __attempts: attempts,
    __reset: () => {
      tasks.clear();
      attempts.clear();
      release = null;
      items = [];
      nextItem = 1;
    },
    __release: () => release,
    __items: () => items,
    isReleaseSchemaReady: jest.fn(async () => true),
    listReleaseCandidates: jest.fn(async () => []),
    listBatchDependenciesForTasks: jest.fn(async () => []),
    listLatestReleaseItemsForTasks: jest.fn(async () => new Map()),
    listRecentReleaseBatches: jest.fn(async () => []),
    findReleaseByIdempotencyKey: jest.fn(async () => null),
    findActiveReleaseItemsForTasks: jest.fn(async () => []),
    getTaskRowUnscoped: jest.fn(async (taskId: string) => tasks.get(taskId) || null),
    patchTask: jest.fn(async (taskId: string, patch: Record<string, unknown>) => {
      const task = tasks.get(taskId);
      if (!task) return null;
      Object.assign(task, patch);
      return task;
    }),
    transitionTask: jest.fn(
      async (input: {
        taskId: string;
        to: string;
        patch?: Record<string, unknown>;
      }) => {
        const task = tasks.get(input.taskId);
        if (!task) return null;
        Object.assign(task, input.patch || {}, { status: input.to });
        return task;
      }
    ),
    appendEvent: jest.fn(async () => undefined),
    patchAttempt: jest.fn(async () => null),
    insertReleaseBatch: jest.fn(
      async (input: {
        repository: string;
        baseRef: string;
        idempotencyKey: string;
        selectedTaskIds: string[];
        mainBeforeSha: string | null;
      }) => {
        release = {
          id: '99999999-9999-4999-8999-999999999999',
          repository: input.repository,
          base_ref: input.baseRef,
          status: 'draft',
          idempotency_key: input.idempotencyKey,
          selected_task_ids: input.selectedTaskIds,
          item_count: input.selectedTaskIds.length,
          main_before_sha: input.mainBeforeSha,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        return {
          release: {
            id: String(release.id),
            status: 'draft',
            repository: input.repository,
            baseRef: input.baseRef,
            itemCount: input.selectedTaskIds.length,
            idempotencyKey: input.idempotencyKey,
            mainBeforeSha: input.mainBeforeSha,
            mainAfterSha: null,
            deploymentId: null,
            deploymentUrl: null,
            deploymentState: null,
            deploymentCheckedAt: null,
            blockReason: null,
            errorCode: null,
            errorMessage: null,
            items: [],
            createdAt: String(release.created_at),
            startedAt: null,
            finishedAt: null,
            updatedAt: String(release.updated_at),
          },
          duplicate: false,
        };
      }
    ),
    insertReleaseItems: jest.fn(
      async (releaseId: string, rows: Array<Record<string, unknown>>) => {
        items = rows.map((row, index) => ({
          id: `00000000-0000-4000-8000-${String(nextItem++).padStart(12, '0')}`,
          release_id: releaseId,
          position: index,
          status: 'ready',
          task_title: row.taskTitle,
          task_id: row.taskId,
          repository: row.repository,
          base_ref: row.baseRef,
          attempt_id: row.attemptId,
          commit_sha: row.commitSha,
          branch: row.branch,
          pr_number: row.prNumber,
          pr_url: row.prUrl,
          changed_files: row.changedFiles,
          checks: row.checks,
          validation: row.validation,
          committed_at: row.committedAt,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }));
        return true;
      }
    ),
    getReleaseBatch: jest.fn(async () => {
      if (!release) return null;
      return {
        id: String(release.id),
        status: String(release.status),
        repository: String(release.repository),
        baseRef: String(release.base_ref),
        itemCount: Number(release.item_count || items.length),
        idempotencyKey: String(release.idempotency_key || ''),
        mainBeforeSha: (release.main_before_sha as string) || null,
        mainAfterSha: (release.main_after_sha as string) || null,
        deploymentId: (release.deployment_id as string) || null,
        deploymentUrl: (release.deployment_url as string) || null,
        deploymentState: (release.deployment_state as string) || null,
        deploymentCheckedAt: (release.deployment_checked_at as string) || null,
        blockReason: (release.block_reason as string) || null,
        errorCode: null,
        errorMessage: null,
        items: items.map((item) => ({
          id: String(item.id),
          releaseId: String(item.release_id),
          taskId: String(item.task_id),
          taskTitle: String(item.task_title),
          repository: String(item.repository),
          baseRef: String(item.base_ref),
          attemptId: (item.attempt_id as string) || null,
          attemptNumber: 1,
          commitSha: String(item.commit_sha),
          branch: String(item.branch),
          prNumber: (item.pr_number as number) || null,
          prUrl: (item.pr_url as string) || null,
          state: String(item.status),
          label: '',
          blockReason: (item.block_reason as string) || null,
          changedFiles: (item.changed_files as string[]) || [],
          checks: (item.checks as []) || [],
          validation: (item.validation as Record<string, unknown>) || {
            status: 'passed',
            detail: 'ok',
            commands: [],
          },
          dependsOn: [],
          committedAt: (item.committed_at as string) || null,
          mainSha: (item.main_sha as string) || null,
          deployedSha: (item.deployed_sha as string) || null,
          deploymentUrl: (item.deployment_url as string) || null,
          deploymentState: (item.deployment_state as string) || null,
          deploymentCheckedAt: (item.deployment_checked_at as string) || null,
          updatedAt: String(item.updated_at),
        })),
        createdAt: String(release.created_at),
        startedAt: (release.started_at as string) || null,
        finishedAt: (release.finished_at as string) || null,
        updatedAt: String(release.updated_at),
      };
    }),
    updateReleaseBatch: jest.fn(
      async (releaseId: string, patch: Record<string, unknown>) => {
        if (!release || release.id !== releaseId) return null;
        Object.assign(release, patch);
        return store.getReleaseBatch();
      }
    ),
    updateReleaseItem: jest.fn(
      async (itemId: string, patch: Record<string, unknown>) => {
        const item = items.find((entry) => entry.id === itemId);
        if (!item) return null;
        Object.assign(item, patch);
        const mapped = await store.getReleaseBatch();
        return mapped?.items.find((entry: { id: string }) => entry.id === itemId) || null;
      }
    ),
  };
  return store;
});

jest.mock('../github', () => ({
  getBranchHead: jest.fn(),
  getCommitChecks: jest.fn(),
  getPullRequestStatus: jest.fn(),
  findPullRequestForBranch: jest.fn(async () => null),
  createPullRequestForAttempt: jest.fn(),
  getVercelDeploymentStatus: jest.fn(),
  isCommitInMain: jest.fn(),
  isCommitOnBranch: jest.fn(),
  mergeVerifiedPullRequest: jest.fn(),
}));

import * as store from '../store';
import * as github from '../github';
import {
  buildReleaseQueue,
  deriveAttemptValidation,
  deriveCommitOutcome,
  orderReleaseItems,
  pushReadyCommits,
  summarizeReleaseItems,
} from '../release';
import type { DevReleaseItem, DevWorkbenchTask } from '../types';

const TASK_ID = '11111111-1111-4111-8111-111111111111';
const TASK_ID_2 = '22222222-2222-4222-8222-222222222222';
const COMMIT = 'a'.repeat(40);
const COMMIT_2 = 'b'.repeat(40);
const MERGE_SHA = 'c'.repeat(40);
const MAIN_SHA = 'd'.repeat(40);

const asMock = (value: unknown) => value as jest.Mock;
const storeMock = store as unknown as {
  __tasks: Map<string, Record<string, unknown>>;
  __attempts: Map<string, Record<string, unknown>>;
  __reset: () => void;
  __release: () => Record<string, unknown> | null;
  __items: () => Array<Record<string, unknown>>;
};

function task(overrides: Partial<DevWorkbenchTask> = {}): DevWorkbenchTask {
  return {
    id: TASK_ID,
    title: 'Task A',
    objective: 'Do the thing.',
    repository: 'newlove',
    baseRef: 'main',
    status: 'committed',
    priority: 0,
    queuePosition: null,
    queuedAt: null,
    attemptCount: 1,
    acceptanceCriteria: ['tests'],
    verificationStatus: 'commit_recorded',
    blockedReason: null,
    lastErrorCode: null,
    lastErrorMessage: null,
    resultCommit: COMMIT,
    resultNotes: '',
    pullRequests: [],
    updatedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
    ...overrides,
  } as DevWorkbenchTask;
}

function attempt(overrides: Record<string, unknown> = {}) {
  return {
    id: 'aaaaaaaa-1111-4111-8111-111111111111',
    taskId: TASK_ID,
    attemptNumber: 1,
    status: 'completed',
    workerId: 'codespace:test',
    branch: `pierrot/dev/${TASK_ID}/1`,
    baseRef: 'main',
    baseCommit: 'e'.repeat(40),
    headSha: COMMIT,
    prNumber: null,
    prUrl: null,
    opencodeSessionId: null,
    exitCode: 0,
    startedAt: new Date().toISOString(),
    finishedAt: new Date().toISOString(),
    heartbeatAt: null,
    leaseExpiresAt: null,
    progressStage: 'completed',
    resultSummary: 'done',
    changedFiles: ['lib/a.ts'],
    commands: [{ name: 'pnpm test', status: 'passed' as const }],
    warnings: [],
    verification: {},
    errorCode: null,
    errorMessage: null,
    logExcerpt: null,
    createdAt: new Date().toISOString(),
    ...overrides,
  };
}

function setupReadyCandidate(overrides: Record<string, unknown> = {}) {
  const taskRow = task(overrides as Partial<DevWorkbenchTask>);
  storeMock.__tasks.set(taskRow.id, taskRow as unknown as Record<string, unknown>);
  asMock(store.listReleaseCandidates).mockResolvedValue([
    { task: taskRow, attempt: attempt({ taskId: taskRow.id }) },
  ]);
  asMock(github.getBranchHead).mockImplementation(async (_repo: string, branch: string) =>
    branch === 'main' ? MAIN_SHA : COMMIT
  );
  asMock(github.isCommitInMain).mockImplementation(async (_repo: string, sha: string) => ({
    inMain: sha === MERGE_SHA,
    status: sha === MERGE_SHA ? 'ahead' : 'behind',
    detail: 'checked',
  }));
  asMock(github.isCommitOnBranch).mockResolvedValue({
    onBranch: true,
    status: 'ahead',
    detail: 'ok',
  });
  asMock(github.getCommitChecks).mockResolvedValue({
    status: 'passed',
    detail: '3 checks passed',
    checks: [
      {
        name: 'verify',
        status: 'completed',
        conclusion: 'success',
        url: null,
      },
    ],
  });
  asMock(github.findPullRequestForBranch).mockResolvedValue(null);
  asMock(github.createPullRequestForAttempt).mockResolvedValue({
    number: 7,
    url: 'https://github.com/merkurov1/newlove/pull/7',
    state: 'open',
  });
  asMock(github.getPullRequestStatus).mockResolvedValue({
    number: 7,
    url: 'https://github.com/merkurov1/newlove/pull/7',
    state: 'open',
    merged: false,
    mergeable: true,
    mergeableState: 'clean',
    headSha: COMMIT,
    baseBranch: 'main',
  });
  asMock(github.mergeVerifiedPullRequest).mockResolvedValue({
    merged: true,
    sha: MERGE_SHA,
    message: '',
  });
  asMock(github.getVercelDeploymentStatus).mockResolvedValue({
    state: 'ready',
    url: 'https://newlove.example.vercel.app',
    target: 'production',
    commitSha: MAIN_SHA,
    deploymentId: 'dpl_1',
    checkedAt: new Date().toISOString(),
    reason: null,
  });
}

beforeEach(() => {
  storeMock.__reset();
  jest.clearAllMocks();
  asMock(store.isReleaseSchemaReady).mockResolvedValue(true);
  asMock(store.listBatchDependenciesForTasks).mockResolvedValue([]);
  asMock(store.listLatestReleaseItemsForTasks).mockResolvedValue(new Map());
  asMock(store.listRecentReleaseBatches).mockResolvedValue([]);
  asMock(store.findReleaseByIdempotencyKey).mockResolvedValue(null);
  asMock(store.findActiveReleaseItemsForTasks).mockResolvedValue([]);
  asMock(store.appendEvent).mockResolvedValue(undefined);
  asMock(store.patchAttempt).mockResolvedValue(null);
});

describe('commit completion decisions', () => {
  it('fails validation when a recorded command failed', () => {
    const validation = deriveAttemptValidation({
      commands: [{ name: 'pnpm test', status: 'failed' }],
      exitCode: 0,
    });
    expect(validation.status).toBe('failed');
    expect(validation.detail).toContain('pnpm test');
  });

  it('treats a non-zero executor exit as validation failure', () => {
    expect(deriveAttemptValidation({ commands: [], exitCode: 1 }).status).toBe('failed');
  });

  it('does not invent validation without evidence', () => {
    expect(deriveAttemptValidation({ commands: [], exitCode: 0 }).status).toBe('unknown');
  });

  it('only marks a task committed when a real SHA and passing validation exist', () => {
    expect(deriveCommitOutcome({ headSha: COMMIT, changedFiles: ['a.ts'] }).status).toBe(
      'committed'
    );
    expect(deriveCommitOutcome({ headSha: null, changedFiles: [] }).status).toBe('no_changes');
    expect(deriveCommitOutcome({ headSha: null, changedFiles: ['a.ts'] }).status).toBe(
      'validation_failed'
    );
    expect(
      deriveCommitOutcome({
        headSha: COMMIT,
        changedFiles: ['a.ts'],
        commands: [{ name: 'pnpm typecheck', status: 'failed' }],
      }).status
    ).toBe('validation_failed');
  });
});

describe('release ordering', () => {
  function item(taskId: string, state: DevReleaseItem['state'] = 'ready'): DevReleaseItem {
    return {
      id: null,
      releaseId: null,
      taskId,
      taskTitle: taskId,
      repository: 'newlove',
      baseRef: 'main',
      attemptId: null,
      attemptNumber: 1,
      commitSha: COMMIT,
      branch: `pierrot/dev/${taskId}/1`,
      prNumber: null,
      prUrl: null,
      state,
      label: '',
      blockReason: null,
      changedFiles: [],
      checks: [],
      validation: { status: 'passed', detail: 'ok', commands: [] },
      dependsOn: [],
      committedAt: new Date().toISOString(),
      mainSha: null,
      deployedSha: null,
      deploymentUrl: null,
      deploymentState: null,
      deploymentCheckedAt: null,
      updatedAt: null,
    };
  }

  it('orders a dependency before its dependent task', () => {
    const result = orderReleaseItems([item(TASK_ID), item(TASK_ID_2)], [
      {
        taskId: TASK_ID_2,
        dependsOnTaskId: TASK_ID,
        dependsOnTitle: 'Task A',
        dependsOnStatus: 'committed',
        batchId: null,
        position: 0,
      },
    ]);
    expect(result.items.map((entry) => entry.taskId)).toEqual([TASK_ID, TASK_ID_2]);
    expect(result.cycle).toEqual([]);
  });

  it('blocks a dependency cycle instead of reordering silently', () => {
    const result = orderReleaseItems([item(TASK_ID), item(TASK_ID_2)], [
      {
        taskId: TASK_ID_2,
        dependsOnTaskId: TASK_ID,
        dependsOnTitle: 'A',
        dependsOnStatus: 'committed',
        batchId: null,
        position: 0,
      },
      {
        taskId: TASK_ID,
        dependsOnTaskId: TASK_ID_2,
        dependsOnTitle: 'B',
        dependsOnStatus: 'committed',
        batchId: null,
        position: 1,
      },
    ]);
    expect(result.cycle.sort()).toEqual([TASK_ID, TASK_ID_2].sort());
    expect(result.items.every((entry) => entry.state === 'blocked')).toBe(true);
  });

  it('summarizes distinct states without pretending committed is deployed', () => {
    const summary = summarizeReleaseItems([
      item(TASK_ID, 'committed'),
      item(TASK_ID_2, 'deployed'),
    ]);
    expect(summary.committedCount).toBe(1);
    expect(summary.deployedCount).toBe(1);
    expect(summary.deploymentPendingCount).toBe(0);
  });
});

describe('preflight', () => {
  it('marks a committed task Ready to Push only after GitHub checks pass', async () => {
    setupReadyCandidate();
    const overview = await buildReleaseQueue('owner', { taskIds: [TASK_ID], refresh: true });
    const entry = overview.items[0];
    expect(entry.state).toBe('ready');
    expect(entry.checks).toHaveLength(1);
    expect(entry.validation.status).toBe('passed');
  });

  it('blocks a merge conflict with an explicit reason', async () => {
    setupReadyCandidate();
    asMock(github.findPullRequestForBranch).mockResolvedValue({
      number: 7,
      url: 'https://github.com/merkurov1/newlove/pull/7',
      state: 'open',
      merged: false,
    });
    asMock(github.getPullRequestStatus).mockResolvedValue({
      number: 7,
      url: 'https://github.com/merkurov1/newlove/pull/7',
      state: 'open',
      merged: false,
      mergeable: false,
      mergeableState: 'dirty',
      headSha: COMMIT,
      baseBranch: 'main',
    });
    const overview = await buildReleaseQueue('owner', { taskIds: [TASK_ID], refresh: true });
    expect(overview.items[0].state).toBe('conflict');
    expect(overview.items[0].blockReason).toContain('merge conflict');
  });

  it('blocks failed CI before any merge', async () => {
    setupReadyCandidate();
    asMock(github.getCommitChecks).mockResolvedValue({
      status: 'failed',
      detail: 'verify failed',
      checks: [],
    });
    const overview = await buildReleaseQueue('owner', { taskIds: [TASK_ID], refresh: true });
    expect(overview.items[0].state).toBe('blocked');
    expect(overview.items[0].blockReason).toContain('CI failed');
  });
});

describe('push ready commits', () => {
  it('does not repeat an existing idempotent request', async () => {
    asMock(store.findReleaseByIdempotencyKey).mockResolvedValue({
      id: '99999999-9999-4999-8999-999999999999',
      status: 'deployed',
    });
    const result = await pushReadyCommits({
      userId: 'owner',
      taskIds: [TASK_ID],
      idempotencyKey: 'same-request-key-1',
    });
    expect(result.duplicate).toBe(true);
    expect(github.mergeVerifiedPullRequest).not.toHaveBeenCalled();
  });

  it('blocks a conflicting batch before inserting a release or merging', async () => {
    setupReadyCandidate();
    asMock(github.getCommitChecks).mockResolvedValue({
      status: 'failed',
      detail: 'verify failed',
      checks: [],
    });
    const result = await pushReadyCommits({ userId: 'owner', taskIds: [TASK_ID] });
    expect(result.ok).toBe(false);
    expect(result.code).toBe('RELEASE_PREFLIGHT_BLOCKED');
    expect(store.insertReleaseBatch).not.toHaveBeenCalled();
    expect(github.mergeVerifiedPullRequest).not.toHaveBeenCalled();
  });

  it('promotes a ready commit, verifies main and only then marks deployed', async () => {
    setupReadyCandidate();
    const result = await pushReadyCommits({ userId: 'owner', taskIds: [TASK_ID] });
    expect(result.ok).toBe(true);
    expect(github.mergeVerifiedPullRequest).toHaveBeenCalledTimes(1);
    expect(store.updateReleaseItem).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({ status: 'in_main', main_sha: MERGE_SHA })
    );
    expect(store.updateReleaseItem).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({ status: 'deployed', deployed_sha: MAIN_SHA })
    );
    expect(store.transitionTask).toHaveBeenCalledWith(
      expect.objectContaining({ to: 'in_main' })
    );
    expect(store.transitionTask).toHaveBeenCalledWith(
      expect.objectContaining({ to: 'deployed' })
    );
  });

  it('keeps a task In main but deployment pending until Vercel confirms READY', async () => {
    setupReadyCandidate();
    asMock(github.getVercelDeploymentStatus).mockResolvedValue({
      state: 'building',
      url: null,
      target: 'production',
      commitSha: MAIN_SHA,
      deploymentId: 'dpl_2',
      checkedAt: new Date().toISOString(),
      reason: 'Deployment is building.',
    });
    const result = await pushReadyCommits({ userId: 'owner', taskIds: [TASK_ID] });
    expect(result.ok).toBe(true);
    expect(store.updateReleaseItem).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({ status: 'deployment_pending' })
    );
    expect(store.transitionTask).not.toHaveBeenCalledWith(
      expect.objectContaining({ to: 'deployed' })
    );
  });

  it('records a partial batch when a later merge fails', async () => {
    const second = task({
      id: TASK_ID_2,
      title: 'Task B',
      resultCommit: COMMIT_2,
    });
    storeMock.__tasks.set(TASK_ID_2, second as unknown as Record<string, unknown>);
    const first = task();
    storeMock.__tasks.set(TASK_ID, first as unknown as Record<string, unknown>);
    setupReadyCandidate();
    asMock(store.listReleaseCandidates).mockResolvedValue([
      { task: first, attempt: attempt({ taskId: TASK_ID }) },
      {
        task: second,
        attempt: attempt({
          id: 'bbbbbbbb-1111-4111-8111-111111111111',
          taskId: TASK_ID_2,
          branch: `pierrot/dev/${TASK_ID_2}/1`,
          headSha: COMMIT_2,
        }),
      },
    ]);
    asMock(github.getBranchHead).mockImplementation(async (_repo: string, branch: string) =>
      branch === 'main' ? MAIN_SHA : branch.includes(TASK_ID_2) ? COMMIT_2 : COMMIT
    );
    asMock(github.createPullRequestForAttempt)
      .mockResolvedValueOnce({
        number: 7,
        url: 'https://github.com/merkurov1/newlove/pull/7',
        state: 'open',
      })
      .mockResolvedValueOnce({
        number: 8,
        url: 'https://github.com/merkurov1/newlove/pull/8',
        state: 'open',
      });
    asMock(github.getPullRequestStatus).mockImplementation(
      async (_repo: string, number: number) => ({
        number,
        url: `https://github.com/merkurov1/newlove/pull/${number}`,
        state: 'open',
        merged: false,
        mergeable: true,
        mergeableState: 'clean',
        headSha: number === 7 ? COMMIT : COMMIT_2,
        baseBranch: 'main',
      })
    );
    asMock(github.mergeVerifiedPullRequest)
      .mockResolvedValueOnce({ merged: true, sha: MERGE_SHA, message: '' })
      .mockRejectedValueOnce(new Error('GitHub merge API failed'));

    const result = await pushReadyCommits({
      userId: 'owner',
      taskIds: [TASK_ID, TASK_ID_2],
    });
    expect(result.ok).toBe(false);
    expect(result.code).toBe('RELEASE_PARTIAL');
    const release = storeMock.__release();
    expect(release?.status).toBe('partial');
    const items = storeMock.__items();
    expect(items[0].status).toBe('deployed');
    expect(items[1].status).toBe('failed');
  });
});
