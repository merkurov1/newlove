import { createHash } from 'crypto';
import { assertServerOnly } from '@/lib/serverOnly';
import {
  appendEvent,
  findActiveReleaseItemsForTasks,
  findReleaseByIdempotencyKey,
  getReleaseBatch,
  getTaskRowUnscoped,
  insertReleaseBatch,
  insertReleaseItems,
  isReleaseSchemaReady,
  listBatchDependenciesForTasks,
  listLatestReleaseItemsForTasks,
  listRecentReleaseBatches,
  listReleaseCandidates,
  patchAttempt,
  patchTask,
  transitionTask,
  updateReleaseBatch,
  updateReleaseItem,
  type DevBatchDependency,
  type DevReleaseCandidate,
} from './store';
import { taskTransitionPath } from './state';
import type {
  DevAttempt,
  DevReleaseBatch,
  DevReleaseItem,
  DevReleaseItemState,
  DevReleaseOverview,
  DevReleaseSummary,
  DevWorkbenchTask,
  DevWorkbenchTaskStatus,
} from './types';

assertServerOnly('lib/pierrot/dev/workbench/release');

const SHA_PATTERN = /^[0-9a-f]{40}$/i;
const MAX_RELEASE_ITEMS = 50;
const INTERRUPTED_AFTER_MS = 3 * 60_000;
const RELEASE_ITEM_STATES = new Set<DevReleaseItemState>([
  'committed',
  'ready',
  'blocked',
  'conflict',
  'already_in_main',
  'pushing',
  'in_main',
  'deployment_pending',
  'deployed',
  'deployment_failed',
  'failed',
  'skipped',
]);

const TERMINAL_DEPENDENCY_STATES: DevWorkbenchTaskStatus[] = [
  'in_main',
  'deployment_pending',
  'deployed',
  'deployment_failed',
];

function nowIso(): string {
  return new Date().toISOString();
}

/**
 * GitHub is loaded lazily so the release summary and the workbench overview do
 * not pull the ESM Octokit client into every read-only Admin page (or test).
 */
type GitHubModule = typeof import('./github');
let githubPromise: Promise<GitHubModule> | null = null;

async function github(): Promise<GitHubModule> {
  githubPromise = githubPromise || import('./github');
  return githubPromise;
}

function clean(value: unknown, limit = 2000): string {
  return typeof value === 'string' ? value.trim().slice(0, limit) : '';
}

export function releaseHash(parts: Array<string | null | undefined>): string {
  return createHash('sha256')
    .update(parts.map((part) => String(part || '')).join('\u0000'), 'utf8')
    .digest('hex')
    .slice(0, 48);
}

export function releaseItemLabel(state: DevReleaseItemState): string {
  const labels: Record<DevReleaseItemState, string> = {
    committed: 'Committed',
    ready: 'Ready to Push',
    blocked: 'Blocked',
    conflict: 'Conflicting',
    already_in_main: 'Already in main',
    pushing: 'Pushing',
    in_main: 'In main',
    deployment_pending: 'Deployment pending',
    deployed: 'Deployed',
    deployment_failed: 'Deployment failed',
    failed: 'Failed',
    skipped: 'Skipped',
  };
  return labels[state];
}

async function hasReleaseSchema(): Promise<boolean> {
  if (typeof isReleaseSchemaReady !== 'function') return false;
  try {
    return await isReleaseSchemaReady();
  } catch {
    return false;
  }
}

export type ValidationSummary = {
  status: 'passed' | 'failed' | 'unknown';
  detail: string;
  commands: Array<{ name: string; status: string; detail?: string }>;
};

/**
 * Validation evidence comes from the worker attempt. A failed command or a
 * non-zero executor exit can never be marked Ready. If no command was reported
 * the result is `unknown`, not a silent pass; preflight can still accept an
 * explicit passing GitHub CI run.
 */
export function deriveAttemptValidation(input: {
  commands?: Array<{ name?: unknown; status?: unknown; detail?: unknown }>;
  exitCode?: number | null;
  verification?: Record<string, unknown> | null;
}): ValidationSummary {
  const explicit = input.verification?.validation;
  if (explicit && typeof explicit === 'object') {
    const record = explicit as Record<string, unknown>;
    const status = String(record.status || '').toLowerCase();
    if (status === 'failed' || status === 'passed' || status === 'unknown') {
      return {
        status,
        detail: clean(record.detail, 2000) || `Executor reported validation: ${status}.`,
        commands: [],
      };
    }
  }

  const commands = Array.isArray(input.commands)
    ? input.commands
        .slice(0, 40)
        .map((command) => ({
          name: clean(command?.name, 300) || 'command',
          status: clean(command?.status, 40) || 'unknown',
          detail: clean(command?.detail, 1000) || undefined,
        }))
    : [];

  const failed = commands.filter((command) => command.status === 'failed');
  if (failed.length > 0) {
    return {
      status: 'failed',
      detail: `${failed.length} validation command(s) failed: ${failed
        .map((command) => command.name)
        .slice(0, 5)
        .join(', ')}.`,
      commands,
    };
  }
  if (typeof input.exitCode === 'number' && input.exitCode !== 0) {
    return {
      status: 'failed',
      detail: `The executor exited with code ${input.exitCode}.`,
      commands,
    };
  }
  const passed = commands.filter((command) => command.status === 'passed');
  if (passed.length > 0) {
    return {
      status: 'passed',
      detail: `${passed.length} validation command(s) passed: ${passed
        .map((command) => command.name)
        .slice(0, 5)
        .join(', ')}.`,
      commands,
    };
  }
  return {
    status: 'unknown',
    detail:
      'No test, lint, typecheck or build command was recorded for this attempt. A passing GitHub CI run is required before Ready to Push.',
    commands,
  };
}

export type CommitOutcome = {
  status: 'committed' | 'validation_failed' | 'no_changes';
  reason: string;
  validation: ValidationSummary;
};

/** Pure completion decision used by completeAttempt and covered by tests. */
export function deriveCommitOutcome(input: {
  headSha: string | null;
  changedFiles: string[];
  commands?: Array<{ name?: unknown; status?: unknown; detail?: unknown }>;
  exitCode?: number | null;
  verification?: Record<string, unknown> | null;
}): CommitOutcome {
  const validation = deriveAttemptValidation(input);
  if (input.changedFiles.length === 0 && !input.headSha) {
    return {
      status: 'no_changes',
      reason: 'The task produced no file changes, so no commit was created.',
      validation,
    };
  }
  if (!input.headSha || !SHA_PATTERN.test(input.headSha)) {
    return {
      status: 'validation_failed',
      reason: 'No committed SHA was recorded for this attempt.',
      validation,
    };
  }
  if (validation.status === 'failed') {
    return { status: 'validation_failed', reason: validation.detail, validation };
  }
  return {
    status: 'committed',
    reason:
      validation.status === 'passed'
        ? validation.detail
        : 'Commit recorded; Ready to Push still requires passing CI or validation evidence.',
    validation,
  };
}

function candidateCommit(candidate: DevReleaseCandidate): string {
  const attemptSha = candidate.attempt?.headSha || '';
  if (SHA_PATTERN.test(attemptSha)) return attemptSha.toLowerCase();
  const taskSha = candidate.task.resultCommit || '';
  return SHA_PATTERN.test(taskSha) ? taskSha.toLowerCase() : '';
}

function candidateBranch(candidate: DevReleaseCandidate): string {
  return clean(candidate.attempt?.branch, 220) || '';
}

function dateValue(value: string | null | undefined): number {
  const time = value ? new Date(value).getTime() : NaN;
  return Number.isFinite(time) ? time : 0;
}

function baseItem(candidate: DevReleaseCandidate): DevReleaseItem {
  const { task, attempt } = candidate;
  const commitSha = candidateCommit(candidate);
  const branch = candidateBranch(candidate);
  const validation = deriveAttemptValidation({
    commands: attempt?.commands,
    exitCode: attempt?.exitCode,
    verification: attempt?.verification || null,
  });
  let state: DevReleaseItemState = 'committed';
  let blockReason: string | null = null;

  if (task.status === 'deployed') state = 'deployed';
  else if (task.status === 'in_main') state = 'in_main';
  else if (task.status === 'deployment_pending') state = 'deployment_pending';
  else if (task.status === 'deployment_failed') state = 'deployment_failed';
  else if (task.status === 'pushing') state = 'pushing';
  else if (task.status === 'validation_failed') {
    state = 'blocked';
    blockReason = task.lastErrorMessage || validation.detail;
  } else if (!commitSha) {
    state = 'blocked';
    blockReason = 'No real commit SHA is recorded for this task.';
  } else if (!branch) {
    state = 'blocked';
    blockReason = 'No working branch is recorded for this commit.';
  } else if (
    attempt &&
    branch !== `pierrot/dev/${task.id}/${attempt.attemptNumber}`
  ) {
    state = 'blocked';
    blockReason = `Branch ${branch} does not match the isolated attempt branch pierrot/dev/${task.id}/${attempt.attemptNumber}.`;
  } else if (validation.status === 'failed') {
    state = 'blocked';
    blockReason = validation.detail;
  }

  return {
    id: null,
    releaseId: null,
    taskId: task.id,
    taskTitle: task.title,
    repository: task.repository,
    baseRef: task.baseRef || 'main',
    attemptId: attempt?.id || null,
    attemptNumber: attempt?.attemptNumber || null,
    commitSha,
    branch,
    prNumber: attempt?.prNumber || null,
    prUrl: attempt?.prUrl || task.pullRequests[0] || null,
    state,
    label: releaseItemLabel(state),
    blockReason,
    changedFiles: attempt?.changedFiles?.length ? attempt.changedFiles : [],
    checks: [],
    validation,
    dependsOn: [],
    committedAt: attempt?.finishedAt || attempt?.createdAt || null,
    mainSha: state === 'in_main' || state === 'deployed' ? commitSha : null,
    deployedSha: state === 'deployed' ? commitSha : null,
    deploymentUrl: null,
    deploymentState:
      state === 'deployment_failed'
        ? 'error'
        : state === 'deployed'
          ? 'ready'
          : state === 'deployment_pending'
            ? 'pending'
            : null,
    deploymentCheckedAt: null,
    updatedAt: task.updatedAt,
  };
}

function dependencyBlockReason(
  item: DevReleaseItem,
  dependency: DevBatchDependency,
  selected: Set<string>
): string | null {
  if (dependency.dependsOnTaskId === item.taskId) {
    return 'The task depends on itself.';
  }
  if (selected.has(dependency.dependsOnTaskId)) return null;
  if (
    dependency.dependsOnStatus &&
    TERMINAL_DEPENDENCY_STATES.includes(dependency.dependsOnStatus)
  ) {
    return null;
  }
  const title = dependency.dependsOnTitle || dependency.dependsOnTaskId.slice(0, 8);
  return `Depends on "${title}", which is not in main and is not part of this release batch.`;
}

function applyDependencies(
  items: DevReleaseItem[],
  dependencies: DevBatchDependency[]
): DevReleaseItem[] {
  const byTask = new Map<string, DevBatchDependency[]>();
  for (const dependency of dependencies) {
    const bucket = byTask.get(dependency.taskId) || [];
    bucket.push(dependency);
    byTask.set(dependency.taskId, bucket);
  }
  const selected = new Set(items.map((item) => item.taskId));
  return items.map((item) => {
    const deps = (byTask.get(item.taskId) || []).map((dependency) => {
      const satisfied =
        selected.has(dependency.dependsOnTaskId) ||
        Boolean(
          dependency.dependsOnStatus &&
            TERMINAL_DEPENDENCY_STATES.includes(dependency.dependsOnStatus)
        );
      const reason = dependencyBlockReason(item, dependency, selected);
      return {
        taskId: dependency.dependsOnTaskId,
        title: dependency.dependsOnTitle,
        satisfied: satisfied && !reason,
      };
    });
    const blocker = (byTask.get(item.taskId) || [])
      .map((dependency) => dependencyBlockReason(item, dependency, selected))
      .find(Boolean);
    if (blocker && ['committed', 'ready'].includes(item.state)) {
      return {
        ...item,
        state: 'blocked' as DevReleaseItemState,
        label: releaseItemLabel('blocked'),
        blockReason: blocker,
        dependsOn: deps,
      };
    }
    return { ...item, dependsOn: deps };
  });
}

/**
 * Kahn topological ordering constrained by batch dependencies. A cycle is
 * reported as blocked instead of being silently reordered.
 */
export function orderReleaseItems(
  items: DevReleaseItem[],
  dependencies: DevBatchDependency[]
): { items: DevReleaseItem[]; cycle: string[] } {
  const selected = new Set(items.map((item) => item.taskId));
  const deps = new Map<string, Set<string>>();
  for (const item of items) deps.set(item.taskId, new Set());
  for (const dependency of dependencies) {
    if (!selected.has(dependency.taskId)) continue;
    if (!selected.has(dependency.dependsOnTaskId)) continue;
    deps.get(dependency.taskId)?.add(dependency.dependsOnTaskId);
  }

  const original = [...items].sort(
    (a, b) =>
      dateValue(a.committedAt) - dateValue(b.committedAt) ||
      a.taskTitle.localeCompare(b.taskTitle)
  );
  const ordered: DevReleaseItem[] = [];
  const remaining = new Set(original.map((item) => item.taskId));
  while (remaining.size > 0) {
    const next = original.find(
      (item) =>
        remaining.has(item.taskId) &&
        [...(deps.get(item.taskId) || [])].every((dep) => !remaining.has(dep))
    );
    if (!next) break;
    ordered.push(next);
    remaining.delete(next.taskId);
  }
  if (remaining.size === 0) return { items: ordered, cycle: [] };
  return {
    items: [
      ...ordered,
      ...original
        .filter((item) => remaining.has(item.taskId))
        .map((item) => ({
          ...item,
          state: 'blocked' as DevReleaseItemState,
          label: releaseItemLabel('blocked'),
          blockReason: 'Dependency cycle detected inside this release selection.',
        })),
    ],
    cycle: [...remaining],
  };
}

async function preflightItem(input: {
  item: DevReleaseItem;
  attempt: DevAttempt | null;
  mainHeads: Map<string, string | null>;
}): Promise<DevReleaseItem> {
  const { item, attempt } = input;
  if (['in_main', 'deployed', 'deployment_pending', 'deployment_failed'].includes(item.state)) {
    return item;
  }
  if (!item.commitSha) return item;
  if (item.blockReason) return item;

  const githubClient = await github();
  const repository = item.repository;
  const baseRef = item.baseRef || 'main';
  const mainHead = input.mainHeads.get(`${repository}:${baseRef}`) || null;

  const inMain = await githubClient.isCommitInMain(repository, item.commitSha, baseRef);
  if (inMain.inMain) {
    return {
      ...item,
      state: 'already_in_main',
      label: releaseItemLabel('already_in_main'),
      mainSha: item.commitSha,
      blockReason: null,
    };
  }
  if (inMain.status === 'unknown') {
    return {
      ...item,
      state: 'blocked',
      label: releaseItemLabel('blocked'),
      blockReason: `GitHub ancestry check failed: ${inMain.detail}`,
    };
  }

  // The worker must have based the commit on the task's recorded base commit.
  if (attempt?.baseCommit && SHA_PATTERN.test(attempt.baseCommit)) {
    const ancestry = await githubClient.isCommitOnBranch(repository, attempt.baseCommit, item.commitSha);
    if (!ancestry.onBranch && ancestry.status !== 'unknown') {
      return {
        ...item,
        state: 'blocked',
        label: releaseItemLabel('blocked'),
        blockReason: `Invalid ancestry: ${item.commitSha.slice(0, 7)} does not descend from the recorded base ${attempt.baseCommit.slice(0, 7)}.`,
      };
    }
  }

  const branchHead = await githubClient.getBranchHead(repository, item.branch);
  if (!branchHead) {
    return {
      ...item,
      state: 'blocked',
      label: releaseItemLabel('blocked'),
      blockReason: `Working branch ${item.branch} no longer exists on GitHub.`,
    };
  }
  if (branchHead.toLowerCase() !== item.commitSha.toLowerCase()) {
    const reachable = await githubClient.isCommitOnBranch(repository, item.commitSha, item.branch);
    if (!reachable.onBranch) {
      return {
        ...item,
        state: 'blocked',
        label: releaseItemLabel('blocked'),
        blockReason: `Commit ${item.commitSha.slice(0, 7)} is not reachable from ${item.branch} (branch head ${branchHead.slice(0, 7)}).`,
      };
    }
  }

  let prNumber = item.prNumber;
  let prUrl = item.prUrl;
  let headSha = item.commitSha;
  const anyPr = await githubClient.findPullRequestForBranch(repository, item.branch, 'all');
  if (anyPr) {
    prNumber = anyPr.number;
    prUrl = anyPr.url;
    const status = await githubClient.getPullRequestStatus(repository, anyPr.number);
    if (status) {
      headSha = status.headSha;
      if (status.merged) {
        return {
          ...item,
          state: 'already_in_main',
          label: releaseItemLabel('already_in_main'),
          prNumber,
          prUrl,
          mainSha: status.headSha,
          blockReason: null,
        };
      }
      if (status.baseBranch !== baseRef) {
        return {
          ...item,
          state: 'blocked',
          label: releaseItemLabel('blocked'),
          prNumber,
          prUrl,
          blockReason: `Pull request #${status.number} targets ${status.baseBranch}, not ${baseRef}.`,
        };
      }
      if (status.state !== 'open') {
        return {
          ...item,
          state: 'blocked',
          label: releaseItemLabel('blocked'),
          prNumber,
          prUrl,
          blockReason: `Pull request #${status.number} is ${status.state} and was not merged.`,
        };
      }
      if (status.headSha.toLowerCase() !== item.commitSha.toLowerCase()) {
        return {
          ...item,
          state: 'conflict',
          label: releaseItemLabel('conflict'),
          prNumber,
          prUrl,
          blockReason: `Pull request #${status.number} head moved to ${status.headSha.slice(0, 7)}, not the validated commit ${item.commitSha.slice(0, 7)}.`,
        };
      }
      if (status.mergeable === false || ['dirty', 'blocked'].includes(status.mergeableState || '')) {
        return {
          ...item,
          state: 'conflict',
          label: releaseItemLabel('conflict'),
          prNumber,
          prUrl,
          blockReason: `Pull request #${status.number} has a merge conflict (${status.mergeableState || 'dirty'}).`,
        };
      }
    }
  }

  const checks = await githubClient.getCommitChecks(repository, headSha);
  if (checks.status === 'failed') {
    return {
      ...item,
      state: 'blocked',
      label: releaseItemLabel('blocked'),
      prNumber,
      prUrl,
      checks: checks.checks,
      blockReason: `Required CI failed: ${checks.detail}`,
    };
  }
  if (checks.status === 'unknown') {
    return {
      ...item,
      state: 'blocked',
      label: releaseItemLabel('blocked'),
      prNumber,
      prUrl,
      checks: checks.checks,
      blockReason: `CI status could not be confirmed: ${checks.detail}`,
    };
  }
  if (checks.status === 'pending') {
    return {
      ...item,
      state: 'blocked',
      label: releaseItemLabel('blocked'),
      prNumber,
      prUrl,
      checks: checks.checks,
      blockReason: `CI is still running: ${checks.detail}`,
    };
  }
  if (checks.status === 'none' && item.validation.status !== 'passed') {
    return {
      ...item,
      state: 'blocked',
      label: releaseItemLabel('blocked'),
      prNumber,
      prUrl,
      checks: checks.checks,
      blockReason:
        'No passing CI check and no recorded passing validation command exist for this commit.',
    };
  }

  return {
    ...item,
    state: 'ready',
    label: releaseItemLabel('ready'),
    prNumber,
    prUrl,
    checks: checks.checks,
    blockReason: null,
    mainSha: mainHead,
  };
}

function summarize(items: DevReleaseItem[]): DevReleaseSummary {
  const count = (state: DevReleaseItemState) =>
    items.filter((item) => item.state === state).length;
  return {
    schemaReady: true,
    migrationFile: '2026-12-11_pierrot_dev_release_pipeline.sql',
    readyCount: count('ready'),
    committedCount: count('committed'),
    blockedCount: count('blocked'),
    conflictCount: count('conflict'),
    inMainCount: count('in_main') + count('already_in_main'),
    deploymentPendingCount: count('deployment_pending'),
    deployedCount: count('deployed'),
    failedCount: count('failed') + count('deployment_failed'),
    selectedCount: 0,
    mainSha: null,
    latestDeployment: null,
    updatedAt: nowIso(),
  };
}

export function summarizeReleaseItems(items: DevReleaseItem[]): DevReleaseSummary {
  const summary = summarize(items);
  const deployment = [...items]
    .filter((item) => item.deploymentState || item.deploymentUrl)
    .sort((a, b) => dateValue(b.deploymentCheckedAt) - dateValue(a.deploymentCheckedAt))[0];
  return {
    ...summary,
    mainSha: items.find((item) => item.mainSha)?.mainSha || null,
    latestDeployment: deployment
      ? {
          state: deployment.deploymentState,
          url: deployment.deploymentUrl,
          commitSha: deployment.deployedSha || deployment.mainSha,
          checkedAt: deployment.deploymentCheckedAt,
        }
      : null,
  };
}

export async function getReleaseSummary(_userId: string): Promise<DevReleaseSummary> {
  const schemaReady = await hasReleaseSchema();
  if (!schemaReady) {
    return {
      schemaReady: false,
      migrationFile: '2026-12-11_pierrot_dev_release_pipeline.sql',
      readyCount: 0,
      committedCount: 0,
      blockedCount: 0,
      conflictCount: 0,
      inMainCount: 0,
      deploymentPendingCount: 0,
      deployedCount: 0,
      failedCount: 0,
      selectedCount: 0,
      mainSha: null,
      latestDeployment: null,
      updatedAt: nowIso(),
    };
  }
  try {
    const candidates = await listReleaseCandidates(200);
    const items = candidates.map(baseItem);
    const [dependencies, releaseItems] = await Promise.all([
      listBatchDependenciesForTasks(items.map((item) => item.taskId)),
      listLatestReleaseItemsForTasks(items.map((item) => item.taskId)),
    ]);
    const enriched = applyDependencies(items, dependencies).map((item) => {
      const persisted = releaseItems.get(item.taskId);
      if (!persisted) return item;
      return {
        ...item,
        id: persisted.id,
        releaseId: persisted.releaseId,
        state: persisted.state,
        label: releaseItemLabel(persisted.state),
        mainSha: persisted.mainSha || item.mainSha,
        deployedSha: persisted.deployedSha || item.deployedSha,
        deploymentUrl: persisted.deploymentUrl || item.deploymentUrl,
        deploymentState: persisted.deploymentState || item.deploymentState,
        deploymentCheckedAt: persisted.deploymentCheckedAt || item.deploymentCheckedAt,
        blockReason: persisted.blockReason || item.blockReason,
      };
    });
    const summary = summarize(enriched);
    const latest = [...releaseItems.values()].sort(
      (a, b) => dateValue(b.deploymentCheckedAt) - dateValue(a.deploymentCheckedAt)
    )[0];
    return {
      ...summary,
      schemaReady: true,
      latestDeployment: latest
        ? {
            state: latest.deploymentState,
            url: latest.deploymentUrl,
            commitSha: latest.deployedSha || latest.mainSha,
            checkedAt: latest.deploymentCheckedAt,
          }
        : null,
    };
  } catch {
    return summarize([]);
  }
}

export type BuildReleaseQueueOptions = {
  taskIds?: string[];
  refresh?: boolean;
  limit?: number;
};

export async function buildReleaseQueue(
  userId: string,
  options: BuildReleaseQueueOptions = {}
): Promise<DevReleaseOverview> {
  const schemaReady = await hasReleaseSchema();
  if (!schemaReady) {
    return {
      summary: await getReleaseSummary(userId),
      items: [],
      batches: [],
      refreshed: false,
      warnings: ['Release pipeline migration is not applied; Ready to Push is disabled.'],
    };
  }

  const limit = Math.min(Math.max(options.limit || 100, 1), 200);
  const wanted = new Set((options.taskIds || []).filter(Boolean));
  const candidates = (await listReleaseCandidates(200))
    .filter((candidate) => wanted.size === 0 || wanted.has(candidate.task.id))
    .slice(0, limit);
  const warnings: string[] = [];
  const dependencies = await listBatchDependenciesForTasks(
    candidates.map((candidate) => candidate.task.id)
  );

  let items = candidates.map(baseItem);

  // A single batch cannot silently span repositories: deployment verification
  // would no longer identify one production revision.
  if (items.length > 1) {
    const repositories = new Set(items.map((item) => `${item.repository}:${item.baseRef}`));
    if (repositories.size > 1) {
      items = items.map((item) => ({
        ...item,
        state: 'blocked',
        label: releaseItemLabel('blocked'),
        blockReason:
          'The selection mixes repositories or base refs. Push ready commits one repository at a time.',
      }));
    }
  }

  if (options.refresh) {
    const githubClient = await github();
    const mainHeads = new Map<string, string | null>();
    for (const item of items) {
      const key = `${item.repository}:${item.baseRef}`;
      if (!mainHeads.has(key)) {
        mainHeads.set(key, await githubClient.getBranchHead(item.repository, item.baseRef));
      }
    }
    const refreshed: DevReleaseItem[] = [];
    for (const candidate of candidates) {
      const item = items.find((entry) => entry.taskId === candidate.task.id);
      if (!item) continue;
      try {
        refreshed.push(
          await preflightItem({
            item,
            attempt: candidate.attempt,
            mainHeads,
          })
        );
      } catch (error) {
        const message =
          error instanceof Error ? error.message : 'GitHub preflight failed.';
        warnings.push(`${item.taskTitle}: ${message}`);
        refreshed.push({
          ...item,
          state: 'blocked',
          label: releaseItemLabel('blocked'),
          blockReason: `Preflight failed: ${message}`,
        });
      }
    }
    items = refreshed;
  }

  const withDeps = applyDependencies(items, dependencies);
  const ordered = orderReleaseItems(withDeps, dependencies);
  if (ordered.cycle.length > 0) {
    warnings.push('A dependency cycle was detected and blocked the affected items.');
  }
  const itemsWithLabels = ordered.items.map((item) => ({
    ...item,
    state: RELEASE_ITEM_STATES.has(item.state) ? item.state : 'blocked',
    label: releaseItemLabel(item.state),
  }));
  const summary = summarize(itemsWithLabels);
  const batches = (await listRecentReleaseBatches(10)).map((batch) => ({
    ...batch,
    items: batch.items.map((item) => ({
      ...item,
      label: releaseItemLabel(item.state),
    })),
  }));

  return {
    summary: {
      ...summary,
      schemaReady: true,
      mainSha:
        itemsWithLabels.find((item) => item.mainSha)?.mainSha || batchMainSha(batches) || null,
      latestDeployment: latestDeployment(itemsWithLabels, batches),
    },
    items: itemsWithLabels,
    batches,
    refreshed: Boolean(options.refresh),
    warnings,
  };
}

function batchMainSha(batches: DevReleaseBatch[]): string | null {
  const batch = batches.find((item) => item.mainAfterSha);
  return batch?.mainAfterSha || null;
}

function latestDeployment(
  items: DevReleaseItem[],
  batches: DevReleaseBatch[]
): DevReleaseSummary['latestDeployment'] {
  const item = [...items]
    .filter((entry) => entry.deploymentState || entry.deploymentUrl)
    .sort((a, b) => dateValue(b.deploymentCheckedAt) - dateValue(a.deploymentCheckedAt))[0];
  if (item) {
    return {
      state: item.deploymentState,
      url: item.deploymentUrl,
      commitSha: item.deployedSha || item.mainSha,
      checkedAt: item.deploymentCheckedAt,
    };
  }
  const batch = batches.find((entry) => entry.deploymentState || entry.deploymentUrl);
  return batch
    ? {
        state: batch.deploymentState,
        url: batch.deploymentUrl,
        commitSha: batch.mainAfterSha,
        checkedAt: batch.deploymentCheckedAt,
      }
    : null;
}

async function moveTaskTo(input: {
  userId: string;
  taskId: string;
  to: DevWorkbenchTaskStatus;
  patch?: Record<string, unknown>;
  event: { type: string; message: string; level?: 'debug' | 'info' | 'warn' | 'error' };
  dedupeKey?: string;
}): Promise<DevWorkbenchTask | null> {
  const task = await getTaskRowUnscoped(input.taskId);
  if (!task) return null;
  if (task.status === input.to) {
    const patched = await patchTask(input.taskId, input.patch || {});
    return patched || task;
  }
  const path = taskTransitionPath(task.status, input.to);
  if (!path) {
    // Reconciliation only: a legacy row may be in a state outside the new
    // path (for example verified -> in_main). Record it explicitly.
    await appendEvent({
      taskId: input.taskId,
      type: 'release.state_reconciled',
      level: 'warn',
      message: `Task status ${task.status} has no legal path to ${input.to}; release metadata was updated explicitly.`,
      payload: { from: task.status, to: input.to },
    }).catch(() => {});
    return patchTask(input.taskId, { ...(input.patch || {}), status: input.to });
  }
  let current = task;
  for (let index = 1; index < path.length; index += 1) {
    const next = path[index];
    const isLast = index === path.length - 1;
    const updated = await transitionTask({
      userId: input.userId,
      taskId: input.taskId,
      to: next,
      patch: isLast ? input.patch : undefined,
      event: isLast ? input.event : undefined,
    });
    if (!updated) {
      // Legacy rows can have a null user_id even though the owner triggered
      // the release. Keep the release state machine consistent and record the
      // explicit repair instead of losing the item's main/deployment progress.
      const repaired = await patchTask(input.taskId, {
        ...(isLast ? input.patch || {} : {}),
        status: next,
      });
      if (!repaired) return current;
      current = repaired;
      continue;
    }
    current = updated;
  }
  return current;
}

async function prForItem(
  item: DevReleaseItem,
  userId: string,
  task: DevWorkbenchTask,
  attempt: DevAttempt | null
): Promise<{ number: number; url: string; headSha: string } | null> {
  const githubClient = await github();
  if (item.prNumber) {
    const status = await githubClient.getPullRequestStatus(item.repository, item.prNumber);
    if (status) {
      return { number: status.number, url: status.url, headSha: status.headSha };
    }
  }
  const existing = await githubClient.findPullRequestForBranch(item.repository, item.branch, 'open');
  if (existing) {
    const status = await githubClient.getPullRequestStatus(item.repository, existing.number);
    if (status) {
      return { number: status.number, url: status.url, headSha: status.headSha };
    }
  }
  const created = await githubClient.createPullRequestForAttempt({
    repository: item.repository,
    head: item.branch,
    base: item.baseRef,
    title: `[Pierrot] ${task.title}`.slice(0, 240),
    body: [
      `Task: ${task.id}`,
      `Commit: ${item.commitSha}`,
      attempt ? `Attempt: ${attempt.attemptNumber} (${attempt.id})` : '',
      '',
      'Created by the owner action "Push ready commits" in Pierrot Admin.',
      'The commit was already validated on its isolated branch; merge is the release action.',
      '',
      'Acceptance criteria:',
      ...task.acceptanceCriteria.map((criterion) => `- ${criterion}`),
    ]
      .filter(Boolean)
      .join('\n'),
  });
  if (attempt) {
    await updateAttemptPr(attempt.id, created.number, created.url);
  }
  await patchTask(task.id, {
    pull_requests: [...new Set([...task.pullRequests, created.url])].slice(-10),
  });
  await appendEvent({
    taskId: task.id,
    attemptId: attempt?.id,
    type: 'release.pull_request.created',
    message: `Pull request #${created.number} created for release.`,
    payload: { url: created.url, commitSha: item.commitSha },
    dedupeKey: `release-pr:${item.commitSha}:${created.number}`,
  }).catch(() => {});
  const status = await githubClient.getPullRequestStatus(item.repository, created.number);
  return {
    number: created.number,
    url: created.url,
    headSha: status?.headSha || item.commitSha,
  };
}

async function updateAttemptPr(attemptId: string, number: number, url: string): Promise<void> {
  try {
    await patchAttempt(attemptId, { pr_number: number, pr_url: url });
  } catch {
    // The PR URL is also stored on the task/release item; attempt repair is best effort.
  }
}

async function markItem(
  item: DevReleaseItem,
  state: DevReleaseItemState,
  patch: Record<string, unknown> = {}
): Promise<DevReleaseItem | null> {
  if (!item.id) return null;
  return updateReleaseItem(item.id, {
    status: state,
    block_reason: state === 'ready' || state === 'deployed' || state === 'in_main' ? null : item.blockReason,
    ...patch,
  });
}

async function verifyDeployment(input: {
  userId: string;
  release: DevReleaseBatch;
  items: DevReleaseItem[];
}): Promise<{ release: DevReleaseBatch; items: DevReleaseItem[] }> {
  const { userId } = input;
  const githubClient = await github();
  const schemaItems = input.items.filter((item) => ['in_main', 'deployment_pending', 'deployment_failed'].includes(item.state));
  if (schemaItems.length === 0) {
    return { release: input.release, items: input.items };
  }
  const repository = input.release.repository;
  const mainAfter = await githubClient.getBranchHead(repository, input.release.baseRef || 'main');
  const checkedAt = nowIso();
  if (!mainAfter) {
    return {
      release:
        (await updateReleaseBatch(input.release.id, {
          status: 'partial',
          error_code: 'MAIN_HEAD_UNAVAILABLE',
          error_message: 'Could not read the main head after promotion.',
          block_reason: 'GitHub main head is unavailable; deployment verification is pending.',
          deployment_checked_at: checkedAt,
        })) || input.release,
      items: input.items,
    };
  }

  const deployment = await githubClient.getVercelDeploymentStatus({
    repository,
    commitSha: mainAfter,
  });
  const nextState: DevReleaseItemState =
    deployment.state === 'ready'
      ? 'deployed'
      : deployment.state === 'error'
        ? 'deployment_failed'
        : 'deployment_pending';

  const updatedItems: DevReleaseItem[] = [];
  for (const item of input.items) {
    if (!['in_main', 'deployment_pending', 'deployment_failed'].includes(item.state)) {
      updatedItems.push(item);
      continue;
    }
    const updated = await updateReleaseItem(item.id || '', {
      status: nextState,
      main_sha: item.mainSha || mainAfter,
      deployed_sha: nextState === 'deployed' ? mainAfter : item.deployedSha || null,
      deployment_id: deployment.deploymentId || null,
      deployment_url: deployment.url,
      deployment_state: deployment.state,
      deployment_checked_at: checkedAt,
      block_reason:
        nextState === 'deployed'
          ? null
          : deployment.reason ||
            (deployment.state === 'error'
              ? 'The Vercel production deployment failed.'
              : 'Waiting for the Vercel production deployment to reach READY.'),
    });
    const taskTo: DevWorkbenchTaskStatus =
      nextState === 'deployed'
        ? 'deployed'
        : nextState === 'deployment_failed'
          ? 'deployment_failed'
          : 'deployment_pending';
    await moveTaskTo({
      userId,
      taskId: item.taskId,
      to: taskTo,
      patch: {},
      event: {
        type:
          nextState === 'deployed'
            ? 'release.task.deployed'
            : nextState === 'deployment_failed'
              ? 'release.task.deployment_failed'
              : 'release.task.deployment_pending',
        level: nextState === 'deployment_failed' ? 'error' : 'info',
        message:
          nextState === 'deployed'
            ? `Vercel production deployment ${deployment.url || ''} is READY for ${mainAfter.slice(0, 7)}.`
            : nextState === 'deployment_failed'
              ? `Vercel production deployment failed: ${deployment.reason || 'unknown reason'}.`
              : `In main at ${mainAfter.slice(0, 7)}; waiting for the Vercel production deployment.`,
      },
      dedupeKey: `release-deployment:${input.release.id}:${item.taskId}:${deployment.state}:${mainAfter}`,
    }).catch(() => {});
    await appendEvent({
      taskId: item.taskId,
      type: 'release.deployment_checked',
      message:
        deployment.state === 'ready'
          ? `Vercel production deployment READY at ${mainAfter.slice(0, 7)}.`
          : `Vercel deployment state: ${deployment.state}.`,
      payload: {
        releaseId: input.release.id,
        mainSha: mainAfter,
        state: deployment.state,
        url: deployment.url,
        commitSha: deployment.commitSha,
      },
      dedupeKey: `release-deployment-checked:${input.release.id}:${item.taskId}:${deployment.state}:${mainAfter}`,
    }).catch(() => {});
    updatedItems.push(
      updated ||
        ({
          ...item,
          state: nextState,
          label: releaseItemLabel(nextState),
          mainSha: item.mainSha || mainAfter,
          deployedSha: nextState === 'deployed' ? mainAfter : item.deployedSha,
          deploymentUrl: deployment.url,
          deploymentState: deployment.state,
          deploymentCheckedAt: checkedAt,
        } as DevReleaseItem)
    );
  }

  const allDeployed = updatedItems
    .filter((item) => item.state !== 'skipped')
    .every((item) => item.state === 'deployed');
  const anyFailed = updatedItems.some((item) =>
    ['deployment_failed', 'failed', 'blocked', 'conflict'].includes(item.state)
  );
  const anyNonDeploymentFailure = updatedItems.some((item) =>
    ['failed', 'blocked', 'conflict'].includes(item.state)
  );
  const anyInMain = updatedItems.some((item) => item.state === 'in_main');
  const status: DevReleaseBatch['status'] = allDeployed
    ? 'deployed'
    : anyFailed || anyNonDeploymentFailure
      ? 'partial'
      : anyInMain
        ? 'in_main'
        : 'deployment_pending';
  const updatedRelease =
    (await updateReleaseBatch(input.release.id, {
      status,
      main_after_sha: mainAfter,
      deployment_id: deployment.deploymentId || null,
      deployment_url: deployment.url,
      deployment_state: deployment.state,
      deployment_checked_at: checkedAt,
      block_reason:
        status === 'deployed'
          ? null
          : deployment.reason ||
            (status === 'deployment_pending'
              ? 'Waiting for the Vercel production deployment to reach READY.'
              : null),
      finished_at: status === 'deployed' || anyFailed ? nowIso() : null,
    })) || { ...input.release, status, mainAfterSha: mainAfter };
  return { release: updatedRelease, items: updatedItems };
}

function releaseStatusFromItems(items: DevReleaseItem[]): DevReleaseBatch['status'] {
  const active = items.filter((item) => item.state !== 'skipped' && item.state !== 'already_in_main');
  if (active.length === 0) return 'in_main';
  if (active.every((item) => item.state === 'deployed')) return 'deployed';
  if (active.some((item) => ['failed', 'blocked', 'conflict', 'deployment_failed'].includes(item.state))) {
    return 'partial';
  }
  if (active.every((item) => item.state === 'deployment_pending')) return 'deployment_pending';
  if (active.every((item) => item.state === 'in_main')) return 'in_main';
  if (active.some((item) => item.state === 'pushing')) return 'pushing';
  return 'partial';
}

/**
 * Recover a promotion interrupted by a restart or network loss. GitHub is the
 * source of truth: a merge already visible there is adopted, otherwise the
 * item is returned to ready so the owner can retry without a duplicate merge.
 */
export async function recoverInterruptedReleases(userId: string): Promise<number> {
  if (!(await hasReleaseSchema())) return 0;
  const githubClient = await github();
  const batches = await listRecentReleaseBatches(20);
  let recovered = 0;
  for (const batch of batches) {
    if (batch.status !== 'pushing') continue;
    const isOldEnough =
      Date.now() - dateValue(batch.startedAt || batch.createdAt) > INTERRUPTED_AFTER_MS;
    if (!isOldEnough) continue;
    let changed = false;
    const items: DevReleaseItem[] = [];
    for (const item of batch.items) {
      if (item.state !== 'pushing' || !item.id) {
        items.push(item);
        continue;
      }
      const status = item.prNumber
        ? await githubClient.getPullRequestStatus(item.repository, item.prNumber)
        : await githubClient.findPullRequestForBranch(item.repository, item.branch, 'all').then((pr) =>
            pr ? githubClient.getPullRequestStatus(item.repository, pr.number) : null
          );
      if (status?.merged) {
        const inMain = await githubClient.isCommitInMain(
          item.repository,
          status.headSha,
          item.baseRef || 'main'
        );
        const next: DevReleaseItemState = inMain.inMain ? 'in_main' : 'blocked';
        const updated = await updateReleaseItem(item.id, {
          status: next,
          pr_number: status.number,
          pr_url: status.url,
          main_sha: inMain.inMain ? status.headSha : null,
          pushed_at: nowIso(),
          block_reason: inMain.inMain
            ? null
            : 'GitHub reports the pull request merged but main ancestry could not be confirmed.',
        });
        await moveTaskTo({
          userId,
          taskId: item.taskId,
          to: inMain.inMain ? 'in_main' : 'blocked',
          event: {
            type: inMain.inMain ? 'release.item.recovered_in_main' : 'release.item.recovery_blocked',
            level: inMain.inMain ? 'info' : 'warn',
            message: inMain.inMain
              ? `Recovered merged commit ${status.headSha.slice(0, 7)} into main.`
              : 'Merge was reported by GitHub but main ancestry is unconfirmed.',
          },
          dedupeKey: `release-recover:${batch.id}:${item.taskId}`,
        }).catch(() => {});
        items.push(
          updated || { ...item, state: next, label: releaseItemLabel(next), mainSha: status.headSha }
        );
      } else {
        const updated = await updateReleaseItem(item.id, {
          status: 'blocked',
          block_reason: 'The push was interrupted before GitHub confirmed a merge. Retry is safe.',
        });
        await moveTaskTo({
          userId,
          taskId: item.taskId,
          to: 'ready_to_push',
          event: {
            type: 'release.item.returned_to_ready',
            level: 'warn',
            message: 'Interrupted push left the commit Ready to Push; no merge was confirmed.',
          },
          dedupeKey: `release-recover-ready:${batch.id}:${item.taskId}`,
        }).catch(() => {});
        items.push(
          updated || {
            ...item,
            state: 'blocked',
            label: releaseItemLabel('blocked'),
            blockReason: 'The push was interrupted before GitHub confirmed a merge.',
          }
        );
      }
      changed = true;
    }
    if (changed) {
      const status = releaseStatusFromItems(items);
      await updateReleaseBatch(batch.id, {
        status: status === 'pushing' ? 'partial' : status,
        block_reason:
          status === 'partial' || status === 'pushing'
            ? 'A previous push was interrupted. Recovered from GitHub state; no duplicate merge was attempted.'
            : null,
        finished_at: status === 'deployed' || status === 'partial' ? nowIso() : null,
      }).catch(() => {});
      await appendEvent({
        type: 'release.recovered',
        level: 'warn',
        message: `Recovered interrupted release ${batch.id}.`,
        payload: { releaseId: batch.id, items: items.length },
        dedupeKey: `release-recovered:${batch.id}:${Math.floor(Date.now() / 60_000)}`,
      }).catch(() => {});
      recovered += 1;
    }
  }
  return recovered;
}

/** Refresh deployment confirmation for a release (explicit/read-driven only). */
export async function refreshReleaseDeployment(
  userId: string,
  releaseId: string
): Promise<DevReleaseBatch | null> {
  const release = await getReleaseBatch(releaseId);
  if (!release) return null;
  if (!['in_main', 'deployment_pending', 'deployment_failed', 'partial', 'deployed'].includes(release.status)) {
    return release;
  }
  if (!release.items.some((item) => ['in_main', 'deployment_pending', 'deployment_failed'].includes(item.state))) {
    return release;
  }
  const result = await verifyDeployment({ userId, release, items: release.items });
  return result.release;
}

/**
 * Bounded, read-driven deployment reconciliation for recent releases. This is
 * called only when Admin explicitly refreshes Ready to Push; it is not a
 * background poll loop and never re-merges a commit.
 */
export async function refreshActiveReleaseDeployments(
  userId: string,
  limit = 5
): Promise<number> {
  if (!(await hasReleaseSchema())) return 0;
  const batches = await listRecentReleaseBatches(20);
  let checked = 0;
  for (const batch of batches) {
    if (checked >= Math.max(1, Math.min(limit, 10))) break;
    if (!['in_main', 'deployment_pending', 'deployment_failed', 'partial'].includes(batch.status)) {
      continue;
    }
    if (
      !batch.items.some((item) =>
        ['in_main', 'deployment_pending', 'deployment_failed'].includes(item.state)
      )
    ) {
      continue;
    }
    await verifyDeployment({ userId, release: batch, items: batch.items }).catch(() => null);
    checked += 1;
  }
  return checked;
}

export type PushReadyResult = {
  ok: boolean;
  code: string | null;
  message: string;
  release: DevReleaseBatch | null;
  overview: DevReleaseOverview;
  duplicate: boolean;
  warnings: string[];
};

function releaseKey(input: { userId: string; taskIds: string[]; idempotencyKey?: string }): string {
  if (input.idempotencyKey && input.idempotencyKey.length >= 8) {
    return input.idempotencyKey.slice(0, 200);
  }
  return `release:${releaseHash([
    input.userId,
    ...[...new Set(input.taskIds)].sort(),
  ])}`;
}

/**
 * The single owner action. Preflight is fully evaluated before any merge; a
 * batch with a conflict, failed check, invalid ancestry or missing dependency
 * is blocked as a whole. Promotions are sequential squash merges through the
 * existing PR architecture, with durable per-item progress because GitHub does
 * not offer an atomic multi-PR merge.
 */
export async function pushReadyCommits(input: {
  userId: string;
  taskIds: string[];
  idempotencyKey?: string;
}): Promise<PushReadyResult> {
  const taskIds = [...new Set(input.taskIds.filter(Boolean))].slice(0, MAX_RELEASE_ITEMS);
  if (taskIds.length === 0) {
    return {
      ok: false,
      code: 'RELEASE_EMPTY_SELECTION',
      message: 'Select at least one committed task.',
      release: null,
      overview: await buildReleaseQueue(input.userId),
      duplicate: false,
      warnings: [],
    };
  }

  const key = releaseKey({ ...input, taskIds });
  const existing = await findReleaseByIdempotencyKey(key);
  if (existing) {
    return {
      ok: existing.status !== 'blocked' && existing.status !== 'failed',
      code: 'RELEASE_DUPLICATE_REQUEST',
      message: `This exact push request already exists (${existing.status}). No merge was repeated.`,
      release: await getReleaseBatch(existing.id),
      overview: await buildReleaseQueue(input.userId),
      duplicate: true,
      warnings: [],
    };
  }

  const active = await findActiveReleaseItemsForTasks(taskIds);
  if (active.length > 0) {
    const existingRelease = await getReleaseBatch(active[0].releaseId || '');
    return {
      ok: false,
      code: 'RELEASE_ALREADY_ACTIVE',
      message:
        'One or more selected commits are already in an active release. No duplicate merge was attempted.',
      release: existingRelease,
      overview: await buildReleaseQueue(input.userId),
      duplicate: true,
      warnings: active.map((item) => item.taskTitle),
    };
  }

  const overview = await buildReleaseQueue(input.userId, {
    taskIds,
    refresh: true,
    limit: MAX_RELEASE_ITEMS,
  });
  const selected = overview.items.filter((item) => taskIds.includes(item.taskId));
  if (selected.length === 0) {
    return {
      ok: false,
      code: 'RELEASE_NOT_FOUND',
      message: 'None of the selected tasks are in the release queue.',
      release: null,
      overview,
      duplicate: false,
      warnings: overview.warnings,
    };
  }

  const alreadyInMain = selected.filter((item) => item.state === 'already_in_main');
  for (const item of alreadyInMain) {
    await moveTaskTo({
      userId: input.userId,
      taskId: item.taskId,
      to: 'in_main',
      event: {
        type: 'release.already_in_main',
        message: `GitHub confirms ${item.commitSha.slice(0, 7)} is already in main.`,
      },
      dedupeKey: `release-already-main:${item.taskId}:${item.commitSha}`,
    }).catch(() => {});
  }

  const ready = selected.filter((item) => item.state === 'ready');
  const blockers = selected.filter((item) =>
    ['blocked', 'conflict', 'failed', 'pushing', 'deployment_failed'].includes(item.state)
  );
  if (blockers.length > 0 || ready.length === 0) {
    const reasons = blockers.map(
      (item) => `${item.taskTitle}: ${item.blockReason || releaseItemLabel(item.state)}`
    );
    await appendEvent({
      type: 'release.preflight.blocked',
      level: 'warn',
      message:
        reasons[0] ||
        'No selected commit is ready to push. Already-in-main selections need no merge.',
      payload: {
        taskIds,
        reasons,
        alreadyInMain: alreadyInMain.map((item) => item.taskId),
      },
      dedupeKey: `release-preflight-blocked:${key}`,
    }).catch(() => {});
    return {
      ok: false,
      code: 'RELEASE_PREFLIGHT_BLOCKED',
      message:
        reasons.length > 0
          ? `Preflight blocked the batch: ${reasons.slice(0, 4).join(' | ')}`
          : 'Every selected commit is already in main; nothing was pushed.',
      release: null,
      overview,
      duplicate: false,
      warnings: overview.warnings,
    };
  }

  const repositories = new Set(ready.map((item) => `${item.repository}:${item.baseRef}`));
  if (repositories.size !== 1) {
    return {
      ok: false,
      code: 'RELEASE_MIXED_REPOSITORY',
      message: 'A release batch must target one repository and base ref.',
      release: null,
      overview,
      duplicate: false,
      warnings: overview.warnings,
    };
  }

  const githubClient = await github();
  const repository = ready[0].repository;
  const baseRef = ready[0].baseRef || 'main';
  const mainBefore = await githubClient.getBranchHead(repository, baseRef);

  const created = await insertReleaseBatch({
    userId: input.userId,
    repository,
    baseRef,
    idempotencyKey: key,
    selectedTaskIds: ready.map((item) => item.taskId),
    mainBeforeSha: mainBefore,
    preflight: {
      ready: ready.map((item) => ({
        taskId: item.taskId,
        commitSha: item.commitSha,
        branch: item.branch,
        checks: item.checks.length,
        validation: item.validation.status,
      })),
      alreadyInMain: alreadyInMain.map((item) => item.taskId),
      warnings: overview.warnings,
      at: nowIso(),
    },
  });
  if (!created.release) {
    return {
      ok: false,
      code: 'RELEASE_CREATE_FAILED',
      message: 'The durable release record could not be created; no merge was attempted.',
      release: null,
      overview,
      duplicate: created.duplicate,
      warnings: overview.warnings,
    };
  }
  const release = created.release;
  if (created.duplicate) {
    return {
      ok: true,
      code: 'RELEASE_DUPLICATE_REQUEST',
      message: 'This push request already exists. No merge was repeated.',
      release: await getReleaseBatch(release.id),
      overview,
      duplicate: true,
      warnings: overview.warnings,
    };
  }

  const inserted = await insertReleaseItems(
    release.id,
    ready.map((item, index) => ({
      taskId: item.taskId,
      taskTitle: item.taskTitle,
      repository: item.repository,
      baseRef: item.baseRef,
      attemptId: item.attemptId,
      position: index,
      commitSha: item.commitSha,
      branch: item.branch,
      prNumber: item.prNumber,
      prUrl: item.prUrl,
      changedFiles: item.changedFiles,
      checks: item.checks,
      validation: item.validation,
      committedAt: item.committedAt,
    }))
  );
  if (!inserted) {
    const failed = await updateReleaseBatch(release.id, {
      status: 'blocked',
      error_code: 'RELEASE_ITEMS_FAILED',
      error_message: 'Release items could not be persisted; no merge was attempted.',
    });
    return {
      ok: false,
      code: 'RELEASE_ITEMS_FAILED',
      message: 'Release items could not be persisted; no merge was attempted.',
      release: failed,
      overview,
      duplicate: false,
      warnings: overview.warnings,
    };
  }

  const startedAt = nowIso();
  const pushing = await updateReleaseBatch(
    release.id,
    {
      status: 'pushing',
      started_at: startedAt,
      item_count: ready.length,
    },
    'draft'
  );
  if (!pushing) {
    // Another request won the draft->pushing race. Never merge twice.
    const current = await getReleaseBatch(release.id);
    return {
      ok: false,
      code: 'RELEASE_ALREADY_PUSHING',
      message: 'This release is already being pushed by another request.',
      release: current,
      overview,
      duplicate: true,
      warnings: overview.warnings,
    };
  }

  let currentRelease = pushing;
  let items = (await getReleaseBatch(release.id))?.items || [];
  const warnings = [...overview.warnings];
  let stopped = false;
  let blockReason: string | null = null;

  for (const item of items) {
    if (stopped) {
      await markItem(item, 'blocked', {
        block_reason:
          blockReason || 'Not pushed because an earlier item in the batch was blocked.',
      });
      continue;
    }
    const task = await getTaskRowUnscoped(item.taskId);
    if (!task) {
      await markItem(item, 'blocked', { block_reason: 'Task no longer exists.' });
      stopped = true;
      blockReason = `${item.taskTitle}: task no longer exists.`;
      continue;
    }
    if (['in_main', 'deployed', 'deployment_pending'].includes(task.status)) {
      await markItem(item, task.status === 'deployed' ? 'deployed' : 'in_main', {});
      continue;
    }
    await markItem(item, 'pushing');
    await moveTaskTo({
      userId: input.userId,
      taskId: item.taskId,
      to: 'pushing',
      event: {
        type: 'release.item.pushing',
        message: `Promoting ${item.commitSha.slice(0, 7)} from ${item.branch}.`,
      },
      dedupeKey: `release-item-pushing:${release.id}:${item.taskId}`,
    }).catch(() => {});

    try {
      const pr = await prForItem(item, input.userId, task, null);
      if (!pr) {
        const prError = new Error('The pull request could not be opened or read.');
        (prError as Error & { code?: string }).code = 'RELEASE_PR_UNAVAILABLE';
        throw prError;
      }
      if (pr.headSha.toLowerCase() !== item.commitSha.toLowerCase()) {
        await markItem(item, 'conflict', {
          pr_number: pr.number,
          pr_url: pr.url,
          block_reason: `PR #${pr.number} head ${pr.headSha.slice(0, 7)} no longer matches the validated commit ${item.commitSha.slice(0, 7)}.`,
        });
        await moveTaskTo({
          userId: input.userId,
          taskId: item.taskId,
          to: 'blocked',
          event: {
            type: 'release.item.conflict',
            level: 'error',
            message: `PR #${pr.number} head moved after validation.`,
          },
          dedupeKey: `release-item-conflict:${release.id}:${item.taskId}`,
        }).catch(() => {});
        stopped = true;
        blockReason = `${item.taskTitle}: PR head moved after validation.`;
        continue;
      }

      const status = await githubClient.getPullRequestStatus(item.repository, pr.number);
      if (status?.merged) {
        const inMain = await githubClient.isCommitInMain(item.repository, status.headSha, item.baseRef);
        const mainSha = inMain.inMain ? status.headSha : item.commitSha;
        await markItem(item, 'in_main', {
          pr_number: pr.number,
          pr_url: pr.url,
          main_sha: mainSha,
          pushed_at: nowIso(),
          block_reason: inMain.inMain ? null : 'GitHub merge confirmed; main ancestry check pending.',
        });
        await moveTaskTo({
          userId: input.userId,
          taskId: item.taskId,
          to: 'in_main',
          event: {
            type: 'release.item.in_main',
            message: `GitHub confirms ${mainSha.slice(0, 7)} is in ${item.baseRef}.`,
          },
          dedupeKey: `release-item-in-main:${release.id}:${item.taskId}`,
        }).catch(() => {});
        continue;
      }

      if (status?.mergeable === false || ['dirty', 'blocked'].includes(status?.mergeableState || '')) {
        await markItem(item, 'conflict', {
          pr_number: pr.number,
          pr_url: pr.url,
          block_reason: `PR #${pr.number} has a merge conflict (${status?.mergeableState || 'dirty'}).`,
        });
        await moveTaskTo({
          userId: input.userId,
          taskId: item.taskId,
          to: 'blocked',
          event: {
            type: 'release.item.conflict',
            level: 'error',
            message: `PR #${pr.number} has a merge conflict. No merge was attempted.`,
          },
          dedupeKey: `release-item-conflict:${release.id}:${item.taskId}`,
        }).catch(() => {});
        stopped = true;
        blockReason = `${item.taskTitle}: merge conflict.`;
        continue;
      }

      const checks = await githubClient.getCommitChecks(item.repository, status?.headSha || item.commitSha);
      if (checks.status === 'failed' || checks.status === 'pending' || checks.status === 'unknown') {
        await markItem(item, 'blocked', {
          pr_number: pr.number,
          pr_url: pr.url,
          checks: checks.checks,
          block_reason: `CI ${checks.status}: ${checks.detail}`,
        });
        await moveTaskTo({
          userId: input.userId,
          taskId: item.taskId,
          to: 'ready_to_push',
          event: {
            type: 'release.item.checks_blocked',
            level: 'warn',
            message: `CI ${checks.status} before merge; item remains Ready to Push.`,
          },
          dedupeKey: `release-item-checks:${release.id}:${item.taskId}`,
        }).catch(() => {});
        stopped = true;
        blockReason = `${item.taskTitle}: CI ${checks.status}.`;
        continue;
      }

      const merged = await githubClient.mergeVerifiedPullRequest({
        repository: item.repository,
        number: pr.number,
        expectedHeadSha: status?.headSha || pr.headSha,
      });
      if (!merged.merged) {
        await markItem(item, 'failed', {
          pr_number: pr.number,
          pr_url: pr.url,
          block_reason: `GitHub did not merge PR #${pr.number}: ${merged.message || 'unknown reason'}.`,
        });
        await moveTaskTo({
          userId: input.userId,
          taskId: item.taskId,
          to: 'ready_to_push',
          event: {
            type: 'release.item.merge_failed',
            level: 'error',
            message: `GitHub did not merge PR #${pr.number}; the commit stays Ready to Push.`,
          },
          dedupeKey: `release-item-merge-failed:${release.id}:${item.taskId}`,
        }).catch(() => {});
        stopped = true;
        blockReason = `${item.taskTitle}: GitHub merge failed.`;
        continue;
      }

      const mainSha = merged.sha || status?.headSha || item.commitSha;
      const mainConfirmed = await githubClient.isCommitInMain(item.repository, mainSha, item.baseRef);
      await markItem(item, 'in_main', {
        pr_number: pr.number,
        pr_url: pr.url,
        main_sha: mainSha,
        pushed_at: nowIso(),
        block_reason: mainConfirmed.inMain
          ? null
          : 'GitHub merge succeeded; main ancestry confirmation is pending.',
      });
      await moveTaskTo({
        userId: input.userId,
        taskId: item.taskId,
        to: 'in_main',
        event: {
          type: 'release.item.in_main',
          message: `Merged PR #${pr.number}; GitHub main now contains ${mainSha.slice(0, 7)}.`,
        },
        dedupeKey: `release-item-in-main:${release.id}:${item.taskId}`,
      }).catch(() => {});
      await appendEvent({
        taskId: item.taskId,
        type: 'release.item.pushed',
        message: `PR #${pr.number} merged into ${item.baseRef} at ${mainSha.slice(0, 7)}.`,
        payload: {
          releaseId: release.id,
          taskId: item.taskId,
          commitSha: item.commitSha,
          prNumber: pr.number,
          mainSha,
          ancestryConfirmed: mainConfirmed.inMain,
        },
        dedupeKey: `release-item-pushed:${release.id}:${item.taskId}:${mainSha}`,
      }).catch(() => {});
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'GitHub promotion failed.';
      warnings.push(`${item.taskTitle}: ${message}`);
      await markItem(item, 'failed', { block_reason: message });
      await moveTaskTo({
        userId: input.userId,
        taskId: item.taskId,
        to: 'ready_to_push',
        event: {
          type: 'release.item.push_error',
          level: 'error',
          message: `Promotion failed: ${message}`,
        },
        dedupeKey: `release-item-error:${release.id}:${item.taskId}:${releaseHash([message])}`,
      }).catch(() => {});
      stopped = true;
      blockReason = `${item.taskTitle}: ${message}`;
    }
  }

  const afterItems = (await getReleaseBatch(release.id))?.items || items;
  const hasMain = afterItems.some((item) =>
    ['in_main', 'deployment_pending', 'deployed', 'deployment_failed'].includes(item.state)
  );
  if (hasMain) {
    const verified = await verifyDeployment({
      userId: input.userId,
      release: currentRelease,
      items: afterItems,
    });
    currentRelease = verified.release;
    items = verified.items;
  } else {
    currentRelease =
      (await updateReleaseBatch(release.id, {
        status: stopped ? 'partial' : 'failed',
        block_reason: blockReason || 'No commit was confirmed in main.',
        finished_at: nowIso(),
      })) || currentRelease;
  }

  const finalOverview = await buildReleaseQueue(input.userId);
  const finalRelease = (await getReleaseBatch(release.id)) || currentRelease;
  const published = items.filter((item) =>
    ['in_main', 'deployment_pending', 'deployed'].includes(item.state)
  );
  const ok = published.length === ready.length && !stopped;
  await appendEvent({
    type: ok ? 'release.completed' : 'release.partial',
    level: ok ? 'info' : 'error',
    message: ok
      ? `Pushed ${published.length} commit(s) to ${baseRef}.`
      : `Release stopped after ${published.length}/${ready.length} commit(s). ${blockReason || ''}`.trim(),
    payload: {
      releaseId: release.id,
      published: published.map((item) => ({
        taskId: item.taskId,
        commitSha: item.commitSha,
        mainSha: item.mainSha,
        state: item.state,
      })),
      remaining: ready.length - published.length,
      atomic: false,
      note: 'GitHub does not support atomic multi-PR squash merges; per-item progress is durable and retry-safe.',
    },
    dedupeKey: `release-finished:${release.id}:${ok ? 'ok' : 'partial'}`,
  }).catch(() => {});

  return {
    ok,
    code: ok ? null : 'RELEASE_PARTIAL',
    message: ok
      ? `Pushed ${published.length} commit(s) to ${baseRef}. Deployment confirmation is tracked per release.`
      : `Release stopped after ${published.length}/${ready.length} commit(s). ${blockReason || 'Review the blocked item.'}`,
    release: finalRelease,
    overview: finalOverview,
    duplicate: false,
    warnings,
  };
}
