import { NextResponse } from 'next/server';
import { requireAdminFromRequest } from '@/lib/serverAuth';
import { getClientIp } from '@/lib/rateLimit';
import { checkPierrotRateLimit } from '@/lib/pierrot/rateLimit';
import {
  buildReleaseQueue,
  pushReadyCommits,
  recoverInterruptedReleases,
  refreshActiveReleaseDeployments,
  refreshReleaseDeployment,
} from '@/lib/pierrot/dev/workbench/release';
import { getWorkbenchOverview } from '@/lib/pierrot/dev/workbench/overview';
import { WorkbenchGitHubError } from '@/lib/pierrot/dev/workbench/github';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

function json(body: unknown, status = 200) {
  return NextResponse.json(body, {
    status,
    headers: {
      'Cache-Control': 'no-store, max-age=0, must-revalidate',
      'X-Robots-Tag': 'noindex, nofollow',
    },
  });
}

export async function GET(req: Request) {
  let admin: Awaited<ReturnType<typeof requireAdminFromRequest>>;
  try {
    admin = await requireAdminFromRequest(req);
  } catch {
    return json({ error: 'Unauthorized' }, 401);
  }

  const url = new URL(req.url);
  const refresh = url.searchParams.get('refresh') === '1';
  const releaseId = url.searchParams.get('releaseId');
  const taskIds = (url.searchParams.get('taskIds') || '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean)
    .slice(0, 50);

  try {
    if (refresh) {
      await recoverInterruptedReleases(admin.id).catch(() => 0);
      await refreshActiveReleaseDeployments(admin.id).catch(() => 0);
    }
    if (releaseId && refresh) {
      await refreshReleaseDeployment(admin.id, releaseId).catch(() => null);
    }
    const release = await buildReleaseQueue(admin.id, {
      refresh,
      taskIds: taskIds.length > 0 ? taskIds : undefined,
    });
    return json({ release });
  } catch (error) {
    console.error('[Pierrot Dev Release] queue failed', {
      code: error instanceof Error ? error.name : 'unknown',
    });
    return json({ error: 'Unable to load Ready to Push.' }, 500);
  }
}

export async function POST(req: Request) {
  let admin: Awaited<ReturnType<typeof requireAdminFromRequest>>;
  try {
    admin = await requireAdminFromRequest(req);
  } catch {
    return json({ error: 'Unauthorized' }, 401);
  }

  // Promotion to main is owner-only. Rate limiting protects the GitHub token
  // from accidental repeated clicks without being an approval step.
  const limited = await checkPierrotRateLimit({
    identifier: `dev-release:${admin.id || getClientIp(req)}`,
    intervalMs: 60 * 1000,
    maxRequests: 20,
    keyPrefix: 'pierrot-dev-release',
  });
  if (limited) return limited;

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return json({ error: 'A JSON body is required.' }, 400);
  if (body.confirm !== true) {
    return json(
      {
        error: 'Push ready commits requires an explicit confirmation.',
        code: 'RELEASE_CONFIRMATION_REQUIRED',
      },
      409
    );
  }
  const taskIds = Array.isArray(body.taskIds)
    ? body.taskIds
        .filter((value): value is string => typeof value === 'string')
        .map((value) => value.trim())
        .filter(Boolean)
        .slice(0, 50)
    : [];
  if (taskIds.length === 0) {
    return json({ error: 'Select at least one committed task.' }, 400);
  }

  try {
    const result = await pushReadyCommits({
      userId: admin.id,
      taskIds,
      idempotencyKey:
        typeof body.idempotencyKey === 'string' ? body.idempotencyKey : undefined,
    });
    const overview = await getWorkbenchOverview(admin.id);
    const status = result.ok
      ? 200
      : result.code === 'RELEASE_PREFLIGHT_BLOCKED' || result.code === 'RELEASE_ALREADY_ACTIVE'
        ? 409
        : 400;
    return json(
      {
        ok: result.ok,
        code: result.code,
        message: result.message,
        duplicate: result.duplicate,
        release: result.release,
        releaseOverview: result.overview,
        warnings: result.warnings,
        overview,
      },
      status
    );
  } catch (error) {
    if (error instanceof WorkbenchGitHubError) {
      return json(
        { error: error.message, code: error.code, status: error.status },
        error.status === 401 || error.status === 403 ? 403 : 502
      );
    }
    console.error('[Pierrot Dev Release] push failed', {
      code: error instanceof Error ? error.name : 'unknown',
    });
    return json({ error: 'Push ready commits failed.', code: 'RELEASE_FAILED' }, 500);
  }
}
